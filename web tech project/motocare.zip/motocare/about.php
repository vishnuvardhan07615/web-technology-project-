<?php
/**
 * ============================================================================
 * MotoCare – Two-Wheeler Service & Mechanic Shop Management System
 * File: about.php
 * Stage 2: Dynamic About Us Page
 * ============================================================================
 */

$pageTitle = 'About Us – MotoCare Two-Wheeler Service & Mechanic Shop';
$pageDescription = 'Learn about MotoCare – Our story, mission, certified mechanic team, and advanced workshop infrastructure for two-wheelers.';
$currentPage = 'about.php';

require_once __DIR__ . '/includes/header.php';
?>

    <!-- ======================================================================
         2. About Hero Banner
         ====================================================================== -->
    <section class="section-padding" style="background: radial-gradient(circle at 50% 0%, rgba(255,94,20,0.15) 0%, transparent 60%);">
      <div class="container">
        <div class="section-header" style="margin-bottom: 2rem;">
          <span class="section-badge">Behind The Workshop</span>
          <h1 class="section-title">Built by Passionate Riders for <span class="text-gradient">Every Two-Wheeler</span></h1>
          <p class="section-subtitle">
            From vintage two-strokes and highway cruisers to modern automated scooters and smart electric two-wheelers, MotoCare is dedicated to keeping your ride safe, powerful, and reliable.
          </p>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         3. Our Story, Mission & Vision
         ====================================================================== -->
    <section class="section-padding" style="padding-top: 1rem;">
      <div class="container">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3.5rem; align-items: center;">
          <div>
            <span class="section-badge">Our Journey</span>
            <h2 style="font-size: 2.25rem; margin-bottom: 1.25rem;">Our Story</h2>
            <p style="color: var(--text-muted); margin-bottom: 1.25rem; line-height: 1.7;">
              MotoCare originated in 2016 as an independent specialized tuning garage founded by veteran motorcycle mechanics. We noticed that two-wheeler riders regularly faced two extremes: expensive authorized dealerships with slow turnaround times, or unauthorized local roadside shops lacking digital diagnostic tools and genuine spares.
            </p>
            <p style="color: var(--text-muted); margin-bottom: 1.75rem; line-height: 1.7;">
              We set out to create a modern hybrid: a high-tech, multi-brand service facility where pricing is transparent, job cards are itemized, mechanics are master craftspeople, and customers receive honest advice without hidden charges.
            </p>

            <div style="display: flex; gap: 1.5rem; flex-wrap: wrap;">
              <div style="border-left: 3px solid var(--accent-orange); padding-left: 1rem;">
                <h4 style="font-size: 1.15rem; color: #ffffff;">Our Mission</h4>
                <p style="font-size: 0.9rem; color: var(--text-muted);">
                  To deliver reliable, high-precision two-wheeler maintenance with upfront transparency, genuine parts, and unmatched turnaround speed.
                </p>
              </div>
              <div style="border-left: 3px solid var(--color-blue); padding-left: 1rem; margin-top: 0.5rem;">
                <h4 style="font-size: 1.15rem; color: #ffffff;">Our Vision</h4>
                <p style="font-size: 0.9rem; color: var(--text-muted);">
                  To be the gold standard in urban two-wheeler care, seamlessly integrating future-ready EV diagnostics with classic mechanical mastery.
                </p>
              </div>
            </div>
          </div>

          <div style="background-color: var(--bg-card); border: 1px solid var(--border-card); border-radius: var(--radius-xl); padding: 2rem; box-shadow: var(--shadow-lg);">
            <img src="images/bikes/scooter.svg" alt="Scooter workshop illustration" style="width: 100%; border-radius: var(--radius-md); margin-bottom: 1.5rem;">
            
            <div style="background-color: var(--bg-surface); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
              <h4 style="font-size: 1.1rem; margin-bottom: 0.35rem; color: #ffffff;">"Your Ride. Our Responsibility."</h4>
              <p style="font-size: 0.875rem; color: var(--text-muted);">
                Every motorcycle or scooter leaving our workshop carries our seal of quality check, giving you the confidence to conquer daily traffic or weekend highways.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         4. Statistics Section
         ====================================================================== -->
    <section class="stats-section" aria-label="Key Achievements">
      <div class="container">
        <div class="stats-grid">
          <div class="stat-item">
            <span class="stat-number">10+</span>
            <span class="stat-label">Years of Excellence</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">5,000+</span>
            <span class="stat-label">Happy Two-Wheeler Owners</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">8+</span>
            <span class="stat-label">Master Technicians</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">99.2%</span>
            <span class="stat-label">On-Time Service Delivery</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         5. Why Customers Trust Us
         ====================================================================== -->
    <section class="section-padding" style="background-color: var(--bg-surface);">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">Integrity First</span>
          <h2 class="section-title">Why Customers Trust MotoCare</h2>
          <p class="section-subtitle">
            A motorcycle is more than transportation—it is your daily freedom. We treat every vehicle with uncompromising respect and precision.
          </p>
        </div>

        <div class="features-grid">
          <div class="feature-box">
            <div class="feature-icon-wrap">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            </div>
            <h3 class="feature-title">Zero Counterfeit Spares</h3>
            <p class="feature-desc">
              Every spark plug, disc pad, chain sprocket, and filter comes directly from authorized OEM distributors with factory barcodes intact.
            </p>
          </div>

          <div class="feature-box">
            <div class="feature-icon-wrap">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            </div>
            <h3 class="feature-title">Total Cost Transparency</h3>
            <p class="feature-desc">
              No surprise bills. We give you a thorough digital estimate before starting work and obtain your explicit consent for any extra repairs.
            </p>
          </div>

          <div class="feature-box">
            <div class="feature-icon-wrap">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            </div>
            <h3 class="feature-title">7-Day Warranty Guarantee</h3>
            <p class="feature-desc">
              All labor and repair jobs are safeguarded by a no-questions-asked 7-day post-service warranty. We stand firmly behind our workmanship.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         6. Workshop Facilities
         ====================================================================== -->
    <section class="section-padding">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">Infrastructure</span>
          <h2 class="section-title">Our Workshop Facilities</h2>
          <p class="section-subtitle">
            Engineered with modern pneumatic equipment, electronic diagnostic tools, and dedicated maintenance bays.
          </p>
        </div>

        <div class="facility-grid">
          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"></path></svg>
            </div>
            <h3 class="feature-title">6 Hydraulic Ramp Bays</h3>
            <p class="feature-desc">
              Ergonomic pneumatic bike lifts that allow 360-degree underbody inspection, preventing accidental drops and scratches.
            </p>
          </div>

          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
            </div>
            <h3 class="feature-title">OBD-II Multi-Brand Scanner</h3>
            <p class="feature-desc">
              Specialized digital scanners for FI engines (BS-VI bikes) to decode MIL error codes, throttle position sensors, and fuel trims.
            </p>
          </div>

          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
            </div>
            <h3 class="feature-title">Dedicated EV Service Bay</h3>
            <p class="feature-desc">
              Equipped with high-voltage insulated tools, BLDC motor test benches, BMS voltage testers, and level-2 fast charging stations.
            </p>
          </div>

          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path></svg>
            </div>
            <h3 class="feature-title">Genuine Spares Inventory</h3>
            <p class="feature-desc">
              On-site storage of fast-moving parts for Honda, Yamaha, TVS, Bajaj, Hero, and Royal Enfield, guaranteeing minimal wait times.
            </p>
          </div>

          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>
            </div>
            <h3 class="feature-title">Eco-Foam Wash Bay</h3>
            <p class="feature-desc">
              High-pressure Italian foam jet washers with pH-neutral motorcycle shampoo and water recycling filtration system.
            </p>
          </div>

          <div class="facility-card">
            <div class="facility-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8h1a4 4 0 0 1 0 8h-1"></path><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path><line x1="6" y1="1" x2="6" y2="4"></line><line x1="10" y1="1" x2="10" y2="4"></line><line x1="14" y1="1" x2="14" y2="4"></line></svg>
            </div>
            <h3 class="feature-title">Air-Conditioned Waiting Lounge</h3>
            <p class="feature-desc">
              High-speed Wi-Fi, premium coffee, charging stations, and a glass-paneled viewing deck overlooking the active workshop floor.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         7. Our Team Section
         ====================================================================== -->
    <section class="section-padding" style="background-color: var(--bg-surface);" aria-labelledby="teamTitle">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">Master Technicians</span>
          <h2 class="section-title" id="teamTitle">Meet Our Expert Team</h2>
          <p class="section-subtitle">
            Our certified mechanics possess decades of cumulative diagnostic mastery across ICE performance engines and next-gen electric powertrains.
          </p>
        </div>

        <div class="team-grid">
          <!-- Arun Kumar -->
          <article class="team-card">
            <div class="team-avatar-wrapper">
              <img src="images/mechanics/arun-kumar.svg" alt="Arun Kumar - Senior Mechanic" class="team-avatar-img" width="110" height="110">
            </div>
            <div class="team-info">
              <h3 class="team-name">Arun Kumar</h3>
              <p class="team-role">Senior Mechanic &amp; Shop Head</p>
              <p class="team-specialty">
                12+ years experience. Specialist in Royal Enfield, Yamaha &amp; KTM high-displacement single and twin engines.
              </p>
            </div>
          </article>

          <!-- Karthik -->
          <article class="team-card">
            <div class="team-avatar-wrapper">
              <img src="images/mechanics/karthik.svg" alt="Karthik - Engine Specialist" class="team-avatar-img" width="110" height="110">
            </div>
            <div class="team-info">
              <h3 class="team-name">Karthik</h3>
              <p class="team-role">Engine Specialist</p>
              <p class="team-specialty">
                9+ years experience. Expert in valve clearance, cylinder reboring, gearbox synchronization, and carburetor tuning.
              </p>
            </div>
          </article>

          <!-- Sanjay -->
          <article class="team-card">
            <div class="team-avatar-wrapper">
              <img src="images/mechanics/sanjay.svg" alt="Sanjay - Electrical Specialist" class="team-avatar-img" width="110" height="110">
            </div>
            <div class="team-info">
              <h3 class="team-name">Sanjay</h3>
              <p class="team-role">Electrical &amp; EV Specialist</p>
              <p class="team-specialty">
                8+ years experience. Certified in EV lithium battery packs, BLDC motor controllers, OBD-II diagnostics, and wiring looms.
              </p>
            </div>
          </article>

          <!-- Praveen -->
          <article class="team-card">
            <div class="team-avatar-wrapper">
              <img src="images/mechanics/praveen.svg" alt="Praveen - Service Technician" class="team-avatar-img" width="110" height="110">
            </div>
            <div class="team-info">
              <h3 class="team-name">Praveen</h3>
              <p class="team-role">Service Technician</p>
              <p class="team-specialty">
                6+ years experience. Master in hydraulic braking systems, front telescopic fork rebuilds, and chain sprocket alignment.
              </p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <!-- ======================================================================
         8. Call to Action Banner
         ====================================================================== -->
    <section class="section-padding">
      <div class="container">
        <div class="cta-banner">
          <h2 class="cta-title">Ready to Experience the MotoCare Difference?</h2>
          <p class="cta-desc">
            Book an appointment today. Let our factory-trained mechanics restore your two-wheeler's optimal throttle response and ride smoothness.
          </p>
          <a href="<?php echo getBookServiceUrl(); ?>" class="btn btn-primary btn-lg">
            <span>Book a Service Slot</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
          </a>
        </div>
      </div>
    </section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
